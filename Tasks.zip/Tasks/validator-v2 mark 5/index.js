import Validator from "./Validator.js"
export default Validator

const v = new Validator();
